// import React from 'react'
import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import OneOneimg from '../Image/oneOne.png'
import { useNavigate } from "react-router-dom";


export default function OneOne() {


    let navigate = useNavigate();
  const CompanyTwoTo = () => {
    navigate("/Two");
  };
  let navigateUser = useNavigate();
  const UserOneTwoTo = () => {
    navigateUser("/OneTwo");
  };



  return (
    <> 
    <div>OneOne</div>
    <div className='container' style={{position: 'relative'}}>
      <img src={OneOneimg} alt='' style={{ width: '100%',
  height: 'auto',
  opacity: '0.3'}}/>
      <div className='centered' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}> 
        <h1>You Belongs to, </h1>
        <div>
        <Stack spacing={2} direction="row">
        <Button variant="contained" onClick={CompanyTwoTo}>Company</Button>
      <Button variant="contained"onClick={UserOneTwoTo}>Normal Person</Button>
    </Stack>
    </div>
        </div>
    </div>

    </>
  )
}
