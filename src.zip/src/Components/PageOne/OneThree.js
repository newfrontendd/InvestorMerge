import React from "react";
import "../CSS/Five.css";
import Companywelcomeimg from "../Image/companywelcomeimg.png";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import oneOne from '../Image/oneOne.png';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';


export default function OneThree() {
  let navigate = useNavigate();
  const SixNavbarTo = () => {
    navigate("/SixNavbar");
  };

  return (
    <>
      <div className='container' style={{ position: 'relative'}}>
<img src={oneOne} alt='' style={{width: '100%',
  height: 'auto',
  opacity: '0.3'}}/>
      <div className='center' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  }}>
        <div className="company-container">
          <div className="logo-container">
            <div className="logo-circle"></div>
            {/* <h1>Company Name</h1> */}
            <Stack direction="row" spacing={2}>
            <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg"  style={{    marginLeft: 'auto',
    marginRight: 'auto',
    width: '100px',
    height: '100px'}}/>
            </Stack>
            <h1>User Name</h1>
          </div>
          <img src={Companywelcomeimg} alt="welcomeImage" />
        </div>
        <Button variant="contained" onClick={SixNavbarTo}>Next</Button>
      </div>
      </div>
    </>
  );
}
