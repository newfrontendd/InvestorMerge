// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import welcomeimg from '../Image/welcomeimg.png'
import { useNavigate } from "react-router-dom";
import oneOneimg from '../Image/oneOne.png';
import OneOne from './OneOne';

export default function One() {

let navigate = useNavigate();
  const OneOneTo = () => {
    navigate("/OneONe");
  };


  return (
    <> 
    <div className='container' style={{position: 'relative'}}>
      <img src={oneOneimg} alt='' style={{ width: '100%',
  height: 'auto',
  opacity: '0.3'}}/>

  <div className='centered' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  }}> 
    <div style={{display:'flex', margin:'1%', padding:'2%'}}>

      <div style={{border:'2px solid black', margin:'5%', padding:'5%'}}>
<h1 style={{color:'#7f00f5'}}>Welcome,</h1>
    {/* <Stack direction="row" spacing={2}> */}
   <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{height:100, width:100,
  marginLeft: 'auto',
  marginRight: 'auto'
}}/>
    {/* </Stack> */}
    <h1 style={{color:'#7f00f5'}}>Make Your dreams come true</h1>
      </div>

      <div style={{border:'2px solid black', margin:'5%', padding:'5%'}}>
<img src={welcomeimg} alt=''/>
      </div>
    </div>
    <div>
    {/* <Stack spacing={2} direction="row"> */}
      <Button variant="contained" onClick={OneOneTo}>Get Started</Button>
    {/* </Stack> */}
    </div>
    </div>
    </div>
    </>
  )
}
