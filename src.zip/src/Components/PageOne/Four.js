// import React from 'react'
import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import oneOne from '../Image/oneOne.png'
import { useNavigate } from "react-router-dom";

// grid
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary
}));

export default function Four() {


  let navigate = useNavigate();
  const FiveTo = () => {
    navigate("/Five");
  };


  return (
    <>
      <div className='container' style={{position: 'relative'}}>Four
      <img src={oneOne} alt='' style={{ width: '100%',
  height: 'auto',
  opacity: '0.3'}}/>
      <div className='center' style={{position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  }}>
        <h1>Just a few more steps!</h1>
        <Box
          component="form"
          sx={{
            "& > :not(style)": { m: 1, width: "50ch" }
          }}
          noValidate
          autoComplete="off"
        >
          <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Item>
                  <TextField
                    id="outlined-basic"
                    label="Company's Valuation"
                    variant="outlined"
                    style={{ width: "50ch" }}
                  />
                </Item>
              </Grid>
              <Grid item xs={12}>
                <Item>
                  <TextField
                    id="outlined-basic"
                    label="No. of employee"
                    variant="outlined"
                    style={{ width: "50ch" }}
                  />
                </Item>
              </Grid>
              <Grid item xs={12}>
                <Item>
                  <TextField
                    id="outlined-basic"
                    label="Company's Type"
                    variant="outlined"
                    style={{ width: "50ch" }}
                  />
                </Item>
              </Grid>
            </Grid>
          </Box>
        </Box>

        <FormControl>
          <FormLabel id="demo-radio-buttons-group-label">
            Have You Invesed Previously
          </FormLabel>
          <RadioGroup
            aria-labelledby="demo-radio-buttons-group-label"
            defaultValue="female"
            name="radio-buttons-group"
          >
            <FormControlLabel value="yes" control={<Radio />} label="Yes" />
            <FormControlLabel value="no" control={<Radio />} label="No" />
          </RadioGroup>
        </FormControl>

        <Stack spacing={2} direction="row" style={{}}>
          <Button variant="contained" onClick={FiveTo}>
            Next
          </Button>
        </Stack>
      </div>
      </div>
    </>
  );
}
