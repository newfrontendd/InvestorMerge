// import React from 'react'
import * as React from "react";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from '@mui/material/Button';
import { useState } from "react";
import placeholder from '../Image/placeholder2.png'
import oneOne from '../Image/oneOne.png';
import { useNavigate } from "react-router-dom";



export default function Two() {


  
 const [{ alt, src }, setImg] = useState({
  src: placeholder,
  alt: "Upload an Image"
});
var size = {
  heigth: "30px",
  width: "40px"
};
const handleImg = (e) => {
  if (e.target.files[0]) {
    setImg({
      src: URL.createObjectURL(e.target.files[0]),
      alt: e.target.files[0].name
    });
  }
};

let navigate = useNavigate();
  const ThreeTo = () => {
    navigate("/Three");
  };

let navigateBack = useNavigate();
  const OneOneTo = () => {
    navigateBack("/OneOne");
  };
  

  return (
    <>
      <div className='container' style={{ position: 'relative'}}>Two
        <img src={oneOne} alt='' style={{width: '100%',
  height: 'auto',
  opacity: '0.3'}}/>
  <div className='center' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  }}> 
      <div style={{display:'flex', border:'2px solid black'}}>
      <div style={{border:'2px solid black', margin:'5%', padding:'5%'}}> 
          <Stack direction="row" spacing={2}>
            <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{
  marginLeft: 'auto',
  marginRight: 'auto',
  height:100, width:100
  }}/>
          </Stack>
          <h1>Welcome to the world of Investors</h1>
          </div>

          <div style={{border:'2px solid black', margin:'5%', padding:'5%'}}>
          <form>
          <input type="text" placeholder="Company name" required  style={{padding:'5%', borderRadius:'50px', margin:'2%', width:'80%'}}/>
          <div style={{border:'2px solid black'}}>
            <input
              type="file"
              accept=".png,.pdf, .jpg, .jpeg"
              id="f02"
             style={{border:'2px solid black', padding:'10px', borderRadius:'20px', margin:'5%'}}
            />
            {/* <label for="f02">Verify documents</label> */}
          </div>
          <div style={{ textAlign: "center" }}>Upload Your Company Pan</div>
          <div  style={{border:'2px solid black', padding:'10px', margin:'5%'}}>
            <input
              type="file"
              accept=".png,.pdf, .jpg, .jpeg"
              id="f02"
              style={{border:'2px solid black', padding:'10px', borderRadius:'20px'}}
             
            />
            
            {/* <label for="f02">Verify documents</label> */}
          </div>
          <div style={{ textAlign: "center" }}>Upload Your Company Pan</div>
          <p>
            <a href="#">need any help for verification</a>
          </p>
          <button type="submit" onClick={ThreeTo}  style={{border:'2px solid black', width:'65%', padding:'5%', backgroundColor:'blueviolet', borderRadius:'50px'}} > 
            Verify
           </button>
        </form>
        </div>
          </div>
        
       
          
     
      </div>
      <button style={{border:'2px solid black', padding:'10px', width:'15%', borderRadius:'50px', backgroundColor:'green'}} onClick={OneOneTo}> 
            Back
           </button>

           </div>
    </>
  );
}
