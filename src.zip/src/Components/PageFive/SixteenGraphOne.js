// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { useNavigate } from "react-router-dom";

// grid
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));


export default function SixteenGraphOne() {


  let navigateInvest = useNavigate();
  const InvestSeventeenTo = () => {
    navigateInvest("/SeventeenGraphTwo");
  };

  
  let navigateNegotiate = useNavigate();
  const NegotiateTo = () => {
    navigateNegotiate("/Eighteen");
  };

  let navigateBack = useNavigate();
  const BackFifteenTo = () => {
    navigateBack("/Fifteen");
  };

  return (
    <> 
    <div>SixteenGraphOne</div>

<div style={{border:'2px solid black', backgroundColor:'blueviolet', margin:'1%', padding:'2%'}}>
<Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{height:'100px', width:'100px'}}/>
     <h2>John dept</h2>
     <p>Ozone pvt.ltd</p>

{/* button */}
     <div >
     <Stack spacing={2} direction="row">
     <Button variant="contained">Changes in Year</Button>
      <Button variant="contained">Changes in Months</Button>
     
    </Stack>
     </div>
    </Stack>

</div>


{/* grid */}
<div>
<Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <Item> <h2> Diluting </h2></Item>
        </Grid>
        <Grid item xs={6}>
          <Item><h2> Present Company Valuation </h2></Item>
        </Grid>
        <Grid item xs={6}>
          <Item><p>x%</p></Item>
        </Grid>
        <Grid item xs={6}>
          <Item><p>80,000 crore</p></Item>
        </Grid>
      </Grid>
    </Box>
</div>

{/* Line graph */}
<div>
  <h1>Line Graph</h1>
</div>

{/* button */}
<div>
<Stack spacing={2} direction="row">
<Button variant="contained">Diluting%($)</Button>
      <Button variant="contained" onClick={InvestSeventeenTo}>Invest</Button>
      <Button variant="contained" onClick={NegotiateTo}>Negotiate</Button>
      <Button variant="text" onClick={BackFifteenTo} >Back</Button>
    </Stack>
</div>
    </>
  )
}
