// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';

export default function Twelve() {
  return (
      <> 
    <div>Twelve</div>
    <div style={{border:'2px solid black', margin:'1%', padding:'2%', backgroundColor:'blueviolet'}}>
    <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{height:'100px', width:'100px'}}/>
      <h2>John dept</h2>
      <p>Ozone pvt.ltd</p>
    </Stack>
    </div>

    {/* TextFields */}
    <div>
    <Box
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '50ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <TextField id="outlined-basic" label="Add Company's description" variant="outlined" />
      <TextField id="outlined-basic" label="Add Company's valuation" variant="outlined" />
      <TextField id="outlined-basic" label="Add No. of employes" variant="outlined" />
      <TextField id="outlined-basic" label="Add Ownership list" variant="outlined" />
      <TextField id="outlined-basic" label="Add Company intrested category" variant="outlined" />
    </Box>
    </div>

{/* button */}
<div>
<Stack spacing={2} direction="row">
      <Button variant="contained">Update</Button>
      <Button variant="text"> <ArrowBackIosNewIcon/> Back</Button>
    </Stack>
</div>


    </>
  )
}
